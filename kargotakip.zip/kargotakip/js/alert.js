﻿function UrunEklemeAlert() {
    alert("Ürün Eklemek için yetkiniz yok");
}
function UrunSilmeAlert() {
    alert("Ürün Silmek için yetkiniz yok");
}