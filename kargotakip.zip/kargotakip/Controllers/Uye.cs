﻿namespace kargotakip.Controllers
{
    public partial class Uye
    {
        public int aliciid { get; set; }
        public int adminid { get; set; }
        public string passwd { get; set; }
        public string username { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        
       
    }
}