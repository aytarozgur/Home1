﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kargotakip.Models;
using kargotakip.Controllers;
using System.Web.Helpers;


namespace kargotakip.Controllers
{
    public class LoginController : Controller
    {
        TraineeDb db = new TraineeDb();
        

        // GET: Login
        public ActionResult Index(string form_username, string form_password)
        {
            {
                ShipmentDel model = new ShipmentDel();
                List<admin> liste = model.RetrieveUserIdPw();
                if (form_username != null)
                {
                    int j = liste.Count();
                    for(int i =0; i< j; ++i)
                    {
                        if(form_username == liste[i].username && form_password == liste[i].passwd)
                        {
                            Session["AdminId"] = "1";
                            Response.Redirect("/Layout/Index");
                            string ad = liste[i].Adi;
                            string soyad = liste[i].Soyadi;
                            int aid = liste[i].aliciid;
                            Session["Aid"] = aid;
                            Session.Add("Adminid", aid);
                            Session.Add("ad", ad);
                            Session.Add("soyad", soyad);
                            
                            break;


                        }
                        
                    }
                }

            }
            
            return View();
        }
        
    }
}