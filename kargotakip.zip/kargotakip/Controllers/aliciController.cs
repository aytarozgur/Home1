﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using kargotakip.Models;

namespace kargotakip.Controllers
{
    public class aliciController : Controller
    {
        private TraineeDb db = new TraineeDb();

        // GET: alici
        public ActionResult Index()
        {
            var alici = db.alici.Include(a => a.gonderici);
            return View(alici.ToList());
        }

        // GET: alici/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            alici alici = db.alici.Find(id);
            if (alici == null)
            {
                return HttpNotFound();
            }
            return View(alici);
        }

        // GET: alici/Create
        public ActionResult Create()
        {
            ViewBag.FirmaId = new SelectList(db.gonderici, "firmaid", "firmaadi");
            return View();
        }

        // POST: alici/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "aliciid,aliciadi,YakaNo,alicinumarası,urunkodu,aliciadresi,FirmaId")] alici alici)
        {
            if (ModelState.IsValid)
            {
                db.alici.Add(alici);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.FirmaId = new SelectList(db.gonderici, "firmaid", "firmaadi", alici.FirmaId);
            return View(alici);
        }

        // GET: alici/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            alici alici = db.alici.Find(id);
            if (alici == null)
            {
                return HttpNotFound();
            }
            ViewBag.FirmaId = new SelectList(db.gonderici, "firmaid", "firmaadi", alici.FirmaId);
            return View(alici);
        }

        // POST: alici/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "aliciid,aliciadi,YakaNo,alicinumarası,urunkodu,aliciadresi,FirmaId")] alici alici)
        {
            if (ModelState.IsValid)
            {
                db.Entry(alici).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.FirmaId = new SelectList(db.gonderici, "firmaid", "firmaadi", alici.FirmaId);
            return View(alici);
        }

        // GET: alici/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            alici alici = db.alici.Find(id);
            if (alici == null)
            {
                return HttpNotFound();
            }
            return View(alici);
        }

        // POST: alici/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            alici alici = db.alici.Find(id);
            db.alici.Remove(alici);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
