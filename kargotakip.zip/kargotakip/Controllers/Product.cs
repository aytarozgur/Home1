﻿namespace kargotakip.Controllers
{
    public class Product
    {
        public string FileName { get; set; }
        public string ImageUrl { get; internal set; }
    }
}