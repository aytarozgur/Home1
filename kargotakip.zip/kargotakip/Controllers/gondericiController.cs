﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using kargotakip.Models;
using System.IO;

namespace kargotakip.Controllers
{
    public class gondericiController : Controller
    {
        private TraineeDb db = new TraineeDb();

        // GET: gonderici
        public ActionResult Index()
        {
            return View(db.gonderici.ToList());
        }
        
        // GET: gonderici/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici);
        }      
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "firmaid,firmaadi,firmaaciklamasi,urunkodu,tarih")] gonderici gonderici)
        {
            if (ModelState.IsValid)
            {
                db.gonderici.Add(gonderici);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(gonderici);
        }

        // GET: gonderici/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici);
        }

        // POST: gonderici/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "firmaid,firmaadi,firmaaciklamasi,urunkodu,tarih")] gonderici gonderici)
        {
            if (ModelState.IsValid)
            {
                db.Entry(gonderici).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(gonderici);
        }

        // GET: gonderici/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici);
        }

        // POST: gonderici/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            gonderici gonderici = db.gonderici.Find(id);
            db.gonderici.Remove(gonderici);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult DosyaYukle(Product product, HttpPostedFileBase file)
        {
            //dosya'nın boyutu ve boşluğu kontrol ediliyor.
            if (file != null && file.ContentLength > 0)
            {
                // dosyanın adı çekiliyor.
                var fileName = Path.GetFileName(file.FileName);
                product.ImageUrl = fileName;
                //dosyanın yükleneceği yolu seçiyoruz.
                var path = Path.Combine(Server.MapPath("/img"), fileName);
                file.SaveAs(path);
                Response.Redirect("/gonderici/Index");
            }
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    
}
