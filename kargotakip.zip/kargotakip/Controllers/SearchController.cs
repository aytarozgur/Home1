﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using kargotakip.Models;

namespace kargotakip.Controllers
{
    public class SearchController : Controller
    {
        private TraineeDb db = new TraineeDb();

        // GET: Search
        public ActionResult Index(string searchString)
        {
            var kayit = from m in db.gonderici
                         select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                kayit = kayit.Where(s => s.urunkodu.Contains(searchString));
        }

            return View(kayit);
        }

        // GET: Search/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici); 
        }

        // GET: Search/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Search/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "firmaid,firmaadi,firmaaciklamasi,urunkodu")] gonderici gonderici)
        {
            if (ModelState.IsValid)
            {
                db.gonderici.Add(gonderici);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(gonderici);
        }

        // GET: Search/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici);
        }

        // POST: Search/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "firmaid,firmaadi,firmaaciklamasi,urunkodu")] gonderici gonderici)
        {
            if (ModelState.IsValid)
            {
                db.Entry(gonderici).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(gonderici);
        }

        // GET: Search/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            gonderici gonderici = db.gonderici.Find(id);
            if (gonderici == null)
            {
                return HttpNotFound();
            }
            return View(gonderici);
        }

        // POST: Search/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            gonderici gonderici = db.gonderici.Find(id);
            db.gonderici.Remove(gonderici);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
