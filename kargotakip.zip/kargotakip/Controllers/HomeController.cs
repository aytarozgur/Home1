﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using kargotakip.Models;
using kargotakip.Controllers;


namespace kargotakip.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index(string logout)
        {
            if (Session["UserId"] == null)
                Response.Redirect("Login");
            if (logout != null)
            {
                Session.Abandon();
                Response.Redirect("Login");
            }
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        
       
    }
}