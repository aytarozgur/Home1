﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace kargotakip.Models
{
    public class ShipmentDel
    {
        public List<admin> RetrieveUserIdPw()
        {
            TraineeDb dbmodel = new TraineeDb();
            List<admin> adminler = dbmodel.admin.ToList<admin>();
            return adminler;

        }
        //public string aliciget()
        //{
            //TraineeDb dbmodel = new TraineeDb();

            //return Newtonsoft.Json.JsonConvert.SerializeObject(dbmodel.alici.Select(x => new { x.aliciadi, x.aliciadresi, x.YakaNo, x.urunkodu, x.alicinumarasi, }).ToList());


        //}

    }
}