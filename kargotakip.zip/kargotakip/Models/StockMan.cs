﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace kargotakip.Models
{
    public class StockMan
    {
       
      

        public List<BringUserIdPw_Result> RetrieveUserIdPw()
        {
            Traineedb entTraineeModel = new Traineedb();
            List<BringUserIdPw_Result> lstBring = entTraineeModel.BringUserIdPw().ToList<BringUserIdPw_Result>();
            return lstBring;

        }
        

    }
}