﻿namespace kargotakip.Models
{
    
    
    public partial class Idpw_result
    {
        //internal string Adi;
        //internal string Soyadi;
        //internal int aliciid;

        public string username { get; set; }
        public string passwd { get; set; }
        public int adminid { get; set; }
    }
}
