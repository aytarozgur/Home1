﻿using MvcLoginApps.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MvcLoginApp.Models;

namespace MvcLoginApps.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        //public ActionResult Index(LoginModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        if (model.Username == "Admin" && model.Password == "1234")
        //        {
        //            FormsAuthentication.SetAuthCookie(model.Username, false);
        //            return RedirectToAction("Index", "Home");
        //        }
        //        else 
        //        {
        //            ModelState.AddModelError("", "Invalid Username or Password");
        //        }
            
        //    }

        //    return View();
        //}
        public ActionResult Index(MvcLoginApp.Models.Kullanici_Bilgileri userModel)
        {
            using (Stajyer2018Entities db = new Stajyer2018Entities())
            {
                var userDetails = db.Kullanici_Bilgileri.Where(x => x.Kullanici_Ad == userModel.Kullanici_Ad && x.Sifre == userModel.Sifre).FirstOrDefault();
                if(userDetails==null)
                {
                    userModel.LoginErrorMessage = "Wrong username or password";
                    return View("Index", userModel);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(userDetails.Kullanici_Ad, false);
                    Session["kullaniciID"] = userDetails.Kullanici_Id;
                    Session["kullaniciAdi"] = userDetails.Kullanici_Ad;
                    return RedirectToAction("Index", "Home");
                }               
            }            
        }
    }
}
