﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcLoginApps.Controllers
{
    public class IptalController : Controller
    {
        //
        // GET: /Iptal/

        public ActionResult Index()
        {
            return View();
        }

    }
}
