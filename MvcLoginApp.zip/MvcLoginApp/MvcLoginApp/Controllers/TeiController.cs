﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcLoginApps.Controllers
{
    public class TeiController : Controller
    {
        //
        // GET: /Tei/

        public ActionResult Index()
        {
            return View();
        }

    }
}
