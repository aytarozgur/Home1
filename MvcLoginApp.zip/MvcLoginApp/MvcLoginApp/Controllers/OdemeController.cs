﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcLoginApps.Controllers
{
    public class OdemeController : Controller
    {
        //
        // GET: /Odeme/

        public ActionResult Index()
        {
            return View();
        }

    }
}
